package com.example.batteryannimation;

// Import necessary classes from the Android framework
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.ImageView;

// Main activity class for the application, which extends AppCompatActivity to leverage Android's activity lifecycle
public class MainActivity extends AppCompatActivity {
    // Declare an ImageView object to display the animated drawable
    ImageView img;

    // onCreate is the entry point of the activity when it is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Call the superclass method to restore any saved instance state
        super.onCreate(savedInstanceState);
        // Set the layout resource for the activity
        setContentView(R.layout.activity_main);

        // Find the ImageView defined in the XML layout by its ID and assign it to the variable 'img'
        ImageView img = findViewById(R.id.img);

        // Set the ImageView's drawable resource to the animation defined in battery_items.xml (assumed to be in the drawable folder)
        // indicating that this is a set of frames for animation.
        img.setImageResource(R.drawable.bird);

        // Retrieve the drawable from the ImageView, which is an AnimationDrawable, and cast it
        AnimationDrawable animationDrawable = (AnimationDrawable) img.getDrawable();

        // Start the animation, which will loop through the frames defined in drawable resource
        animationDrawable.start();
    }
}
